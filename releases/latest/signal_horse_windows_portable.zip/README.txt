Signal Horse Portable (Windows)

1. Run "Start Signal Executor.cmd" to start the local service and open the browser UI.
2. The local UI runs at http://127.0.0.1:38182/
3. The first time you open it, Signal Horse asks whether the Web UI should stay public or require a username and password for every visit.
4. If you choose password mode, you can later change it from Settings > Web UI Access inside the page, or reset it from this folder with: SignalHorse.exe web-ui set-password --username <name>
5. A console window stays open while the local service is running. Keep it minimized; closing that window stops the local service.
6. Run "Stop Signal Executor.cmd" to stop the local service.
7. If Windows shows a security warning on first run, right-click SignalHorse.exe, open Properties, and click Unblock if that button is shown.
8. Some antivirus products may quarantine unsigned local executables. If the start script says the service did not become ready, allow SignalHorse.exe and run it again.
9. This package stays in user space and does not require administrator rights.