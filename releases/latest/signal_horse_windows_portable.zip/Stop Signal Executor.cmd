@echo off
taskkill /IM SignalHorse.exe /F >nul 2>&1
exit /b 0