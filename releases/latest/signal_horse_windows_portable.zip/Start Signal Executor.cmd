@echo off
setlocal EnableExtensions
set "BASE_DIR=%~dp0"
set "EXECUTOR=%BASE_DIR%SignalHorse.exe"
set "UI_URL=http://127.0.0.1:38182/"

if not exist "%EXECUTOR%" (
  echo SignalHorse.exe was not found in:
  echo %BASE_DIR%
  pause
  exit /b 1
)

call :wait_for_port
if errorlevel 1 (
  pushd "%BASE_DIR%"
  start "" /B SignalHorse.exe
  if errorlevel 1 (
    popd
    echo Signal Executor could not be started.
    pause
    exit /b 1
  )
  popd
)

for /L %%I in (1,1,20) do (
  call :wait_for_port
  if not errorlevel 1 goto open_ui
  timeout /t 1 /nobreak >nul
)

echo Signal Executor did not become ready on http://127.0.0.1:38182/.
echo.
echo Common causes:
echo 1. Windows Security or another antivirus blocked SignalHorse.exe.
echo 2. Another program is already using port 38182.
echo 3. Windows blocked the downloaded executable on first run.
echo.
echo Try this:
echo - Right-click SignalHorse.exe, open Properties, and click Unblock if shown.
echo - Allow SignalHorse.exe in Windows Security or your antivirus product.
echo - Run SignalHorse.exe manually once to inspect any warning dialog.
pause
exit /b 1

:open_ui
start "" "%UI_URL%"
endlocal
exit /b 0

:wait_for_port
where curl.exe >nul 2>&1
if not errorlevel 1 (
  curl.exe --silent --fail http://127.0.0.1:38182/health >nul 2>&1
  if errorlevel 1 exit /b 1
  exit /b 0
)

netstat -ano -p tcp | findstr /R /C:":38182 .*LISTENING" >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0